HTML5 Canvas Fire Simulation
===========================

There are two types of simulations:

* Cartoonish ([demo](http://zufallsgenerator.github.io/firesimulation/index.html))
* Realistic ([demo](http://zufallsgenerator.github.io/firesimulation/realistic.html))


